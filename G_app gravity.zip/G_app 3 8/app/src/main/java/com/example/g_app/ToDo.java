package com.example.g_app;

// Code from ListWithJSON example from Dustin

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONArray;
import org.w3c.dom.Text;

import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.view.View;
import android.content.Intent;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ToDo extends AppCompatActivity {

    private static final String TAG = "JSON_LIST";
    public static Map events = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_to_do);


    }
    protected void onResume() {
        super.onResume();
        ListView list = (ListView) findViewById(R.id.data_list_view);
        TextView text = (TextView) findViewById(R.id.text);
        text.setVisibility(View.INVISIBLE);


            FirebaseAuth auth = FirebaseAuth.getInstance();
            String userID = auth.getCurrentUser().getUid();
            DatabaseReference current_user_db = FirebaseDatabase.getInstance().getReference().child("Users").child(userID);
            Log.i("in on resume", " //");


            current_user_db.child("ToDo List").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snapshot) {
                    events = (Map)snapshot.getValue();

                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                }
            });


            if(events != null) {
                final ArrayList<ListData> aList = new ArrayList<ListData>();
                String[] listItems = new String[events.size()];

                int i = 0;

                for (Object key : events.keySet()) {

                    ListData ld = new ListData();
                    Map eventData = (Map) events.get(key);

                    listItems[i] = (String)eventData.get("first") + "\n"+ (String)eventData.get("date");

                    ld.firstText = (String) eventData.get("first");
                    ld.secondText = (String) eventData.get("second");
                    ld.latitude = (String) eventData.get("latitude");
                    ld.longitude = (String) eventData.get("longitude");
                    ld.time = (String) eventData.get("time");
                    ld.date = (String) eventData.get("date");

                    aList.add(ld);
                    i++;
                }

                // Show the list view with the each list item an element from listItems
                ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, listItems);
                //list.setAdapter(adapter);
                //ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.custom_textview, listItems);
                list.setAdapter(adapter);

                // Create an array and assign each element to be the title
                // field of each of the ListData objects (from the array list)
                /*String[] listItems = new String[aList.size()];

                for(int i = 0; i < aList.size(); i++){
                    ListData listD = aList.get(i);
                    listItems[i] = listD.firstText;
                }

                // Show the list view with the each list item an element from listItems
                ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, listItems);
                list.setAdapter(adapter);*/

                // Set an OnItemClickListener for each of the list items
                final Context context = this;
                list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                        ListData selected = aList.get(position);

                        // Create an Intent to reference our new activity, then call startActivity
                        // to transition into the new Activity.
                        Intent detailIntent = new Intent(context, DetailActivity.class);

                        // pass some key value pairs to the next Activity (via the Intent)
                        detailIntent.putExtra("first", selected.firstText);
                        detailIntent.putExtra("second", selected.secondText);
                        detailIntent.putExtra("latitude", selected.latitude);
                        detailIntent.putExtra("longitude", selected.longitude);
                        detailIntent.putExtra("time", selected.time);
                        detailIntent.putExtra("date", selected.date);

                        startActivity(detailIntent);
                    }

                });
            }else{
                text.setVisibility(View.VISIBLE);
            }
        }




    // This method will just show the menu item (which is our button "ADD")
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu items for use in the action bar
        MenuInflater inflater = getMenuInflater();
        TextView empty = (TextView)findViewById(R.id.text);
        // the menu being referenced here is the menu.xml from res/menu/menu.xml
        inflater.inflate(R.menu.menu, menu);
        if (events == null){
            empty.setVisibility(View.VISIBLE);
        } else if (events.size() == 0){
            empty.setVisibility(View.VISIBLE);
        } else {

        }
        return super.onCreateOptionsMenu(menu);
    }

    /* Here is the event handler for the menu button that I forgot in class.
    The value returned by item.getItemID() is
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Log.d(TAG, String.format("" + item.getItemId()));
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.action_favorite:
                Intent i = new Intent(this, AddText.class);
                startActivity(i);
                break;
            case R.id.my_profile:
                Intent j = new Intent(this, ProfileActivity.class);
                startActivity(j);
                break;
            default:
                super.onOptionsItemSelected(item);
        }
        return true;
    }

}
