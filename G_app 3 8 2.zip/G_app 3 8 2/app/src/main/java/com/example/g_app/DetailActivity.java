package com.example.g_app;

import android.content.Context;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.widget.TextView;
import android.widget.Button;
import android.widget.EditText;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONArray;
import org.w3c.dom.Text;

import java.io.IOException;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

import android.view.View;
import android.content.Intent;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        Intent i = getIntent();
        String title = i.getStringExtra("first");
        String description = i.getStringExtra("second");
        String latitude = i.getStringExtra("latitude");
        String longitude = i.getStringExtra("longitude");
        String time = i.getStringExtra("time");
        String date = i.getStringExtra("date");

        TextView t = (TextView)findViewById(R.id.textView3);
        TextView d = (TextView)findViewById(R.id.textView4);
        TextView lat = (TextView)findViewById(R.id.lat);
        TextView longi = (TextView)findViewById(R.id.longi);
        TextView ti = (TextView)findViewById(R.id.time);
        TextView da = (TextView)findViewById(R.id.date);

        Button b = (Button) findViewById(R.id.button2);

        t.setText(title);
        d.setText(description);
        lat.setText(latitude);
        longi.setText(longitude);
        ti.setText(time);
        da.setText(date);
    }
}
