package com.example.g_app;

public class PublicDetailActivity {
}
