package com.example.g_app;

public class ListData {
    public String firstText;
    public String secondText;
    public String latitude;
    public String longitude;
    public String time;
    public String date;
}